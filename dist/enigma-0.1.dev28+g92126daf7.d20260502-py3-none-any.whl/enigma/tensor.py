"""Tensor = pointer + Layout. Supports both JIT-time symbolic ops and kernel-time IR tracing."""

from __future__ import annotations

from typing import Any

from .core import Layout
from .core import zipped_divide as _layout_zipped_divide
from .tuple import flatten, idx2crd, is_int, is_tuple, product


class Tensor:
    """Unified tensor: buffer name + layout + base offset.

    Handles both layout algebra (slicing, TV composition) and direct IR
    tracing (scalar load/store, atomics, threadgroup memory).
    """

    def __init__(
        self, name: str, buffer_index: int, metal_dtype: str,
        layout: "Layout | None" = None, base_offset: Any = 0,
        address_space: str = "device", shape: "int | None" = None,
    ):
        self.name = name
        self.buffer_index = buffer_index
        self.metal_dtype = metal_dtype
        self.layout = layout
        self.base_offset = base_offset
        self.address_space = address_space
        self._static_shape = shape  # for threadgroup alloc (static size)

    @property
    def shape(self):
        return self.layout.shape

    @property
    def stride(self):
        return self.layout.stride

    @property
    def element_type(self):
        return self.metal_dtype

    def size(self, mode=None):
        if self.layout is None:
            return self._static_shape or 0
        return self.layout.size(mode)

    def _attrs(self):
        return {
            "buffer": self.name,
            "buffer_index": self.buffer_index,
            "address_space": self.address_space,
            "dtype": self.metal_dtype,
            "shape": self._static_shape,
        }

    def __getitem__(self, coord):
        """Indexing: single IRValue → scalar load, tuple with None → layout slice."""
        from ._tracing import IRValue, IROp, get_builder, _ensure_ir

        if not isinstance(coord, tuple):
            if isinstance(coord, IRValue) or isinstance(coord, int):
                idx = _ensure_ir(coord)
                builder = get_builder()
                assert builder is not None
                result = builder.new_value(self.metal_dtype)
                builder.record(IROp("load", result, [idx], attrs=self._attrs()))
                return result
            coord = (coord,)

        if self.layout is None:
            raise TypeError("Layout algebra requires a Layout on the Tensor")

        shape = self.layout.shape if is_tuple(self.layout.shape) else (self.layout.shape,)
        stride = self.layout.stride if is_tuple(self.layout.stride) else (self.layout.stride,)

        offset = self.base_offset
        new_shapes, new_strides = [], []

        for i, c in enumerate(coord):
            s_i, d_i = shape[i], stride[i]

            if c is None:
                new_shapes.append(s_i)
                new_strides.append(d_i)
            elif isinstance(c, IRValue):
                offset = _add_ir_offset(offset, c, s_i, d_i)
            elif is_int(c):
                offset = _add_static_offset(offset, c, s_i, d_i)
            elif is_tuple(c) and is_tuple(s_i):
                sub_shapes, sub_strides = [], []
                for j, cc in enumerate(c):
                    ss = s_i[j]
                    dd = d_i[j] if is_tuple(d_i) else d_i
                    if cc is None:
                        sub_shapes.append(ss)
                        sub_strides.append(dd)
                    elif isinstance(cc, IRValue):
                        offset = _add_ir_offset(offset, cc, ss, dd)
                    elif is_int(cc):
                        offset = _add_static_offset(offset, cc, ss, dd)
                if sub_shapes:
                    new_shapes.append(sub_shapes[0] if len(sub_shapes) == 1 else tuple(sub_shapes))
                    new_strides.append(
                        sub_strides[0] if len(sub_strides) == 1 else tuple(sub_strides)
                    )

        if not new_shapes:
            return offset

        new_shape = new_shapes[0] if len(new_shapes) == 1 else tuple(new_shapes)
        new_stride = new_strides[0] if len(new_strides) == 1 else tuple(new_strides)
        return Tensor(
            self.name,
            self.buffer_index,
            self.metal_dtype,
            Layout(new_shape, new_stride),
            base_offset=offset,
            address_space=self.address_space,
        )

    def __setitem__(self, coord, value):
        from ._tracing import IROp, IRValue, get_builder, _ensure_ir

        if not isinstance(coord, tuple):
            coord = (coord,)
        if len(coord) == 1 and (isinstance(coord[0], IRValue) or isinstance(coord[0], int)):
            idx = _ensure_ir(coord[0])
            builder = get_builder()
            assert builder is not None
            builder.record(IROp("store", None, [idx, value], attrs=self._attrs()))
            return
        raise TypeError("Use .store() for TV-layout kernels")

    def load(self):
        """Vectorized load of all elements in this tensor view."""
        from ._tracing import IROp, get_builder

        builder = get_builder()
        assert builder is not None

        flat_s, flat_d = flatten(self.layout.shape), flatten(self.layout.stride)
        n_elem = product(self.layout.shape)
        groups = _group_contiguous(_compute_value_offsets(flat_s, flat_d, n_elem))

        result = builder.new_value(self.metal_dtype)
        result._tv_groups = groups
        builder.record(
            IROp(
                "tv_load",
                result,
                [],
                attrs={
                    "buffer": self.name,
                    "buffer_index": self.buffer_index,
                    "base_offset": self.base_offset,
                    "groups": groups,
                    "dtype": self.metal_dtype,
                    "num_elements": n_elem,
                },
            )
        )
        return result

    def store(self, value):
        """Vectorized store of all elements."""
        from ._tracing import IROp, get_builder

        builder = get_builder()
        assert builder is not None

        flat_s, flat_d = flatten(self.layout.shape), flatten(self.layout.stride)
        n_elem = product(self.layout.shape)
        groups = _group_contiguous(_compute_value_offsets(flat_s, flat_d, n_elem))

        builder.record(
            IROp(
                "tv_store",
                None,
                [value],
                attrs={
                    "buffer": self.name,
                    "buffer_index": self.buffer_index,
                    "base_offset": self.base_offset,
                    "groups": groups,
                    "dtype": self.metal_dtype,
                    "num_elements": n_elem,
                },
            )
        )

    def __repr__(self):
        return f"Tensor({self.name}, layout={self.layout}, offset={self.base_offset})"

    # --- Atomics (delegate to _tracing helpers) ---
    def atomic_load(self, index, order="relaxed"):
        from ._tracing import _atomic_load
        return _atomic_load(self, index, order)

    def atomic_store(self, index, value, order="relaxed"):
        from ._tracing import _atomic_store
        _atomic_store(self, index, value, order)

    def atomic_exchange(self, index, value, order="relaxed"):
        from ._tracing import _atomic_rmw
        return _atomic_rmw("atomic_exchange", self, index, value, order)

    def atomic_fetch_add(self, index, value, order="relaxed"):
        from ._tracing import _atomic_rmw
        return _atomic_rmw("atomic_fetch_add", self, index, value, order)

    def atomic_fetch_sub(self, index, value, order="relaxed"):
        from ._tracing import _atomic_rmw
        return _atomic_rmw("atomic_fetch_sub", self, index, value, order)

    def atomic_fetch_min(self, index, value, order="relaxed"):
        from ._tracing import _atomic_rmw
        return _atomic_rmw("atomic_fetch_min", self, index, value, order)

    def atomic_fetch_max(self, index, value, order="relaxed"):
        from ._tracing import _atomic_rmw
        return _atomic_rmw("atomic_fetch_max", self, index, value, order)

    def atomic_fetch_and(self, index, value, order="relaxed"):
        from ._tracing import _atomic_rmw
        return _atomic_rmw("atomic_fetch_and", self, index, value, order)

    def atomic_fetch_or(self, index, value, order="relaxed"):
        from ._tracing import _atomic_rmw
        return _atomic_rmw("atomic_fetch_or", self, index, value, order)

    def atomic_fetch_xor(self, index, value, order="relaxed"):
        from ._tracing import _atomic_rmw
        return _atomic_rmw("atomic_fetch_xor", self, index, value, order)

    def atomic_compare_exchange_weak(self, index, expected, desired,
                                     success_order="relaxed", failure_order="relaxed"):
        from ._tracing import _atomic_cas
        return _atomic_cas(self, index, expected, desired, success_order, failure_order)


def tensor_composition(tensor: Tensor, tv_layout: Layout, tiler) -> Tensor:
    """Compose tensor's tile layout with a TV layout.

    Converts TV layout strides from col-major tile indices to actual memory offsets.
    """
    tile_stride = (
        tensor.layout.stride if is_tuple(tensor.layout.stride) else (tensor.layout.stride,)
    )
    tiler_t = tiler if is_tuple(tiler) else (tiler,)

    def _convert_stride(tile_linear_stride):
        if is_int(tile_linear_stride):
            coord = idx2crd(tile_linear_stride, tiler_t)
            if is_tuple(coord):
                return sum(c * d for c, d in zip(coord, tile_stride))
            return coord * tile_stride[0]
        return tuple(_convert_stride(s) for s in tile_linear_stride)

    new_stride = (_convert_stride(tv_layout.stride[0]), _convert_stride(tv_layout.stride[1]))
    return Tensor(
        tensor.name,
        tensor.buffer_index,
        tensor.metal_dtype,
        Layout(tv_layout.shape, new_stride),
        base_offset=tensor.base_offset,
    )


def tensor_zipped_divide(tensor: Tensor, tiler) -> Tensor:
    """Tile a tensor using zipped_divide.

    Raises EnigmaError if the tiler shape exceeds the tensor shape in any
    dimension — this would produce a zero-element grid and silently return
    wrong results.
    """
    from ._tracing import EnigmaError

    # Normalise shapes to tuples for per-mode comparison
    t_shape = tensor.layout.shape
    t_shape_t = t_shape if is_tuple(t_shape) else (t_shape,)

    if isinstance(tiler, (int, tuple)) and not isinstance(tiler, Layout):
        tiler_shape = tiler if is_tuple(tiler) else (tiler,)
    elif isinstance(tiler, Layout):
        tiler_shape = tiler.shape if is_tuple(tiler.shape) else (tiler.shape,)
    else:
        tiler_shape = (tiler,)

    for i in range(min(len(t_shape_t), len(tiler_shape))):
        tensor_dim = product(t_shape_t[i])
        tiler_dim = product(tiler_shape[i])
        if tensor_dim < tiler_dim:
            raise EnigmaError(
                f"Tiler shape exceeds tensor shape in mode {i}: "
                f"tensor has {tensor_dim} elements but tiler requires {tiler_dim}. "
                f"The tile must fit within the tensor in every dimension."
            )

    new_layout = _layout_zipped_divide(tensor.layout, tiler)
    return Tensor(
        tensor.name,
        tensor.buffer_index,
        tensor.metal_dtype,
        new_layout,
        base_offset=tensor.base_offset,
    )


def make_identity_tensor(shape) -> Tensor:
    return Tensor("__identity__", -1, "uint", Layout(shape))


# --- Internal helpers ---


def _add_static_offset(base, idx: int, shape, stride):
    if is_tuple(shape):
        coord = idx2crd(idx, shape)
        flat_c = flatten((coord,) if is_int(coord) else coord)
        contribution = sum(c * d for c, d in zip(flat_c, flatten(stride)))
    else:
        contribution = idx * stride
    return base + contribution


def _add_ir_offset(base, ir_idx, shape, stride):
    """Generate IR arithmetic for runtime index decomposition."""
    flat_s = flatten(shape) if is_tuple(shape) else (shape,)
    flat_d = flatten(stride) if is_tuple(stride) else (stride,)

    contribution, remaining = None, ir_idx
    for s, d in zip(flat_s, flat_d):
        component = remaining % s if len(flat_s) > 1 else remaining
        if len(flat_s) > 1:
            remaining = remaining // s
        term = component * d
        contribution = term if contribution is None else contribution + term

    if contribution is None:
        return base
    if isinstance(base, int) and base == 0:
        return contribution
    return base + contribution


def _compute_value_offsets(flat_shape, flat_stride, n_elem):
    offsets = []
    for vid in range(n_elem):
        off, idx = 0, vid
        for s, d in zip(flat_shape, flat_stride):
            off += (idx % s) * d
            idx //= s
        offsets.append(off)
    return offsets


def _group_contiguous(offsets):
    """Group offsets into contiguous runs for vectorization."""
    if not offsets:
        return []
    groups, start, count = [], offsets[0], 1
    for i in range(1, len(offsets)):
        if offsets[i] == offsets[i - 1] + 1:
            count += 1
        else:
            groups.append((start, count))
            start, count = offsets[i], 1
    groups.append((start, count))
    return groups
